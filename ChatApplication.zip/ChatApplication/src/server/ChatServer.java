import java.net.ServerSocket;
import java.net.Socket;

public class ChatServer {

    public static void main(String[] args) {

        try {
            ServerSocket serverSocket = new ServerSocket(5000);
            System.out.println("Chat Server Started...");

            while (true) {

                Socket socket = serverSocket.accept();
                System.out.println("Client Connected");

                ClientHandler handler = new ClientHandler(socket);
                new Thread(handler).start();

            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
