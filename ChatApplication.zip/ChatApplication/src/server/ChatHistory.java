import java.io.FileWriter;
import java.io.IOException;

public class ChatHistory {

    private static final String FILE_NAME = "chat_history.txt";

    public static void saveMessage(String message) {

        try {

            FileWriter writer = new FileWriter(FILE_NAME, true);

            writer.write(message + "\n");

            writer.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
