import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.net.Socket;

public class ChatClientGUI {

    private JFrame frame;
    private JTextArea chatArea;
    private JTextField messageField;
    private JList<String> userList;
    private DefaultListModel<String> listModel;

    private PrintWriter out;
    private BufferedReader in;

    public ChatClientGUI() {

        frame = new JFrame("Java Chat Application");

        chatArea = new JTextArea();
        chatArea.setEditable(false);

        messageField = new JTextField();

        listModel = new DefaultListModel<>();
        userList = new JList<>(listModel);

        frame.setLayout(new BorderLayout());

        frame.add(new JScrollPane(chatArea), BorderLayout.CENTER);
        frame.add(messageField, BorderLayout.SOUTH);
        frame.add(new JScrollPane(userList), BorderLayout.EAST);

        frame.setSize(500, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);

        messageField.addActionListener(e -> {

            out.println(messageField.getText());
            messageField.setText("");

        });

        connectToServer();
    }

    private void connectToServer() {

        try {

            Socket socket = new Socket("localhost", 5000);

            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            out = new PrintWriter(socket.getOutputStream(), true);

            String username = JOptionPane.showInputDialog(
                    frame,
                    "Enter Username",
                    "Login",
                    JOptionPane.PLAIN_MESSAGE
            );

            out.println(username);

            new Thread(() -> {

                try {

                    String message;

                    while ((message = in.readLine()) != null) {

                        if (message.startsWith("ONLINE_USERS:")) {

                            updateUserList(message);

                        } else {

                            chatArea.append(message + "\n");

                        }

                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }

            }).start();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void updateUserList(String message) {

        listModel.clear();

        String users = message.replace("ONLINE_USERS:", "");

        String[] userArray = users.split(",");

        for (String user : userArray) {
            listModel.addElement(user);
        }
    }

    public static void main(String[] args) {

        new ChatClientGUI();

    }
}
