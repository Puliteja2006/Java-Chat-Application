import java.io.*;
import java.net.Socket;
import java.util.*;

public class ClientHandler implements Runnable {

    private static Map<String, PrintWriter> clients = new HashMap<>();

    private Socket socket;
    private BufferedReader in;
    private PrintWriter out;
    private String username;

    public ClientHandler(Socket socket) {
        this.socket = socket;
    }

    public void run() {

        try {

            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter(socket.getOutputStream(), true);

            out.println("Enter Username:");
            username = in.readLine();

            clients.put(username, out);

            broadcast("🔔 " + username + " joined the chat");

            sendOnlineUsers();

            String message;

            while ((message = in.readLine()) != null) {

                if (message.startsWith("@")) {

                    String[] parts = message.split(" ", 2);
                    String targetUser = parts[0].substring(1);

                    PrintWriter target = clients.get(targetUser);

                    if (target != null) {
                        target.println("(Private) " + username + ": " + parts[1]);
                    }

                } else {

                    String formatted = username + ": " + message;

                    broadcast(formatted);

                    ChatHistory.saveMessage(formatted);

                }

            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {

            try {

                clients.remove(username);

                broadcast("❌ " + username + " left the chat");

                sendOnlineUsers();

                socket.close();

            } catch (Exception e) {
            }
        }
    }

    private void broadcast(String message) {

        for (PrintWriter writer : clients.values()) {
            writer.println(message);
        }

    }

    private void sendOnlineUsers() {

        String users = "ONLINE_USERS:" + String.join(",", clients.keySet());

        for (PrintWriter writer : clients.values()) {
            writer.println(users);
        }

    }
}
